# little thing

`little_thing` is an experimental semantic cognition architecture built from the conversation's design rather than a conventional language model pipeline.

It is **not a claim of consciousness or sentience**. It is a small dynamical system for studying persistent semantic state, bounded working memory, autonomous association, selective expression, and history-dependent behaviour.

## Architecture

```text
                     semantic substrate
                           │
                 ┌─────────┴─────────┐
                 │                   │
             LEFT                 RIGHT
        conservative           exploratory
                 │                   │
          hot/dormant           hot/dormant
            pockets               pockets
                 │                   │
                 └──── thought pool ─┘
                           │
                    late expression
                     "amygdala"
                           │
             tiny SELF + tiny USER
               created only here
                           │
                 speak / think / unknown
```

Alongside that is a **private journal** of at most 128 local semantic graphs. Each journal object is a maximum 48-node graph with a 48×48 adjacency matrix. Journal entries are not values, beliefs, personality fields, or rewards. They are recurrent wandering thoughts that were mechanically preserved.

When the journal is full, forgetting is automatic:

1. least-used entry first;
2. oldest access breaks ties.

There is no reward or punishment signal.

## No editable values structure

There is deliberately no `values`, `morality`, `goodness`, `personality_score`, or reinforcement field. Long-run tendencies can only appear indirectly in semantic traffic, repeated trajectories, pocket reopening, journal survival, and expression habits.

If you later ask the system to describe what it appears to value, that should be *derived from its accumulated semantic topology*, not read from a values file.

## Files

- `substrate.py` — word coordinates and local semantic graph construction
- `pockets.py` — hot/dormant working-memory lifecycle
- `traffic.py` — long-run semantic traffic, not named values
- `journal.py` — 128 private 48-node journal graphs with LFU/LRU eviction
- `hemisphere.py` — common dynamical engine
- `left.py` — conservative hemisphere
- `right.py` — exploratory hemisphere
- `voice.py` — observed expression habits/favourite words
- `amygdala.py` — thought pool → tokens → expression, with tiny late SELF/USER
- `reader.py` — ingest long-form prose as context rather than questions
- `daydream.py` — autonomous private wandering and journal capture
- `brain.py` — whole concurrent system
- `persistence.py` — state save/restore
- `cli.py` — command line interface

The included `sheridan_coordinates.npz` is the experimental semantic coordinate substrate built earlier from the Sheridan dictionary scan. It contains OCR artefacts; those are intentionally not silently corrected here.

## Install

```bash
python -m pip install -e .
```

## Ask

```bash
little-thing --ask "what is courage?"
```

## Read a text, daydream, then ask

```bash
little-thing --read book.txt --daydream 10000 --ask "what stayed with you?" --save state.json
```

Or in Python:

```python
from little_thing import LittleThing, Reader, Daydreamer

brain = LittleThing()
Reader(brain).read(open("book.txt").read())
Daydreamer(brain).run(10000)
print(brain.ask("what is courage?"))
```

## Important experimental boundary

Private daydreaming does not automatically become SELF, USER, speech, or a named belief. SELF and USER are reconstructed only at the last expression stage and are capped at 12 words by default.

That separation is deliberate:

```text
thought != memory != identity != speech
```
