from pathlib import Path
from little_thing import LittleThing, Reader, Daydreamer, save_brain

brain = LittleThing()
text = """
Language carries meaning through words, relation, rhythm and silence. A pause can divide,
connect, or make an idea noticeable. What repeatedly returns may become easier to revisit.
"""
Reader(brain).read(text, words_per_chunk=40, steps_per_chunk=20)
Daydreamer(brain).run(2000)
print(brain.ask("what is language?"))
save_brain(brain, "little_thing_state.json")
