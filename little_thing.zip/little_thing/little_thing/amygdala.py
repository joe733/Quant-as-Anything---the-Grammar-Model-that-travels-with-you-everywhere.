from __future__ import annotations
import re
from collections import Counter, deque
from .voice import Voice

class Amygdala:
    """Late-bound expression centre.

    Cognition happens elsewhere. SELF and USER are tiny, transient reconstructions made
    only when deciding whether/how to express a converged thought.
    """
    def __init__(self, self_words=12, user_words=12):
        self.self_words = self_words
        self.user_words = user_words
        self.voice = Voice("own")
        self.outcome_memory = deque(maxlen=48)
        self.turn = 0

    @staticmethod
    def _unique(words, cap):
        out = []
        for w in words:
            if w and w not in out:
                out.append(w)
            if len(out) >= cap:
                break
        return out

    def thought_pool(self, left, right, pocket_words=(), journal_words=()):
        score = Counter()
        for rank, w in enumerate(left.get("concepts", [])):
            score[w] += 2.0 / (1 + rank)
        for rank, w in enumerate(right.get("concepts", [])):
            score[w] += 1.35 / (1 + rank)
        overlap = set(left.get("concepts", [])) & set(right.get("concepts", []))
        for w in overlap:
            score[w] += 1.75
        for w in set(pocket_words):
            if w in score:
                score[w] += .30
        for w in set(journal_words):
            if w in score:
                score[w] += .15
        tokens = [w for w, _ in score.most_common(12)]
        support = len(overlap) / max(1, min(len(set(left.get("concepts", []))), len(set(right.get("concepts", [])))))
        lconf = left.get("confidence", 0.0)
        rconf = right.get("confidence", 0.0)
        confidence = .58 * lconf + .27 * support + .15 * rconf
        mean_distance = left.get("mean_distance")
        resolved = bool(overlap) and support >= .18 and confidence >= .58 and (mean_distance is not None and mean_distance < .12)
        return {"tokens": tokens, "overlap": sorted(overlap), "support": support, "confidence": confidence, "resolved": resolved}

    def _late_self(self, pool, left, right):
        # Derived from this moment only; no persistent editable values/personality block.
        words = []
        if pool["resolved"]:
            words += ["resolved", "converged"]
        else:
            words += ["uncertain", "unfinished"]
        words += left.get("concepts", [])[:3]
        words += right.get("concepts", [])[:3]
        words += self.voice.favourites(3)
        return self._unique(words, self.self_words)

    def _late_user(self, query):
        words = re.findall(r"[a-z]+", (query or "").lower())
        return self._unique(words, self.user_words)

    def express(self, query, pool, left, right, cycle, max_cycles):
        self.turn += 1
        if pool["resolved"] and pool["tokens"]:
            decision = "speak"
            chosen = pool["tokens"][:5]
            # Minimal deterministic prose layer; replaceable without changing cognition.
            prose = "I resolve this around " + ", ".join(chosen[:3])
            if len(chosen) > 3:
                prose += "; nearby: " + ", ".join(chosen[3:])
            prose += "."
            self.voice.observe_expression(chosen)
        elif cycle < max_cycles:
            decision, chosen, prose = "think", [], ""
        else:
            decision, chosen, prose = "unknown", [], "I don't know."
        # SELF/USER are created now, after cognition and decision formation.
        result = {
            "decision": decision,
            "confidence": pool["confidence"],
            "thought_tokens": pool["tokens"][:5],
            "prose": prose,
            "self": self._late_self(pool, left, right),
            "user": self._late_user(query),
            "voice_favourites": self.voice.favourites(),
        }
        self.outcome_memory.append({"turn": self.turn, "decision": decision, "tokens": result["thought_tokens"]})
        return result
