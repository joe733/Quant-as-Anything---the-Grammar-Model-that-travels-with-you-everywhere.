from __future__ import annotations
import argparse, json
from pathlib import Path
from .brain import LittleThing
from .reader import Reader
from .daydream import Daydreamer
from .persistence import save_brain


def main():
    ap = argparse.ArgumentParser(prog="little-thing")
    ap.add_argument("--ask")
    ap.add_argument("--read", dest="read_path")
    ap.add_argument("--daydream", type=int, metavar="TRANSITIONS")
    ap.add_argument("--save")
    args = ap.parse_args()

    brain = LittleThing()
    if args.read_path:
        text = Path(args.read_path).read_text(encoding="utf-8", errors="ignore")
        print(json.dumps(Reader(brain).read(text), indent=2))
    if args.daydream:
        print(json.dumps(Daydreamer(brain).run(args.daydream), indent=2))
    if args.ask:
        print(json.dumps(brain.ask(args.ask), indent=2))
    if args.save:
        save_brain(brain, args.save)
        print(args.save)
    if not any((args.ask, args.read_path, args.daydream, args.save)):
        print(json.dumps(brain.snapshot(), indent=2))

if __name__ == "__main__":
    main()
