from dataclasses import dataclass

@dataclass(frozen=True)
class LittleThingConfig:
    # Active working memory
    left_hot_cap: int = 6
    right_hot_cap: int = 8
    left_dormant_cap: int = 48
    right_dormant_cap: int = 64

    # Journal: private, bounded, mechanically forgotten.
    journal_capacity: int = 128
    journal_nodes: int = 48

    # Late-bound expression hints only.
    self_words: int = 12
    user_words: int = 12

    # Bounded cognition before an answer is permitted to fail.
    cognition_cycles: int = 4
    steps_per_cycle: int = 120

    # Context/pocket mechanics.
    context_shift_distance: float = 0.22
    left_sleep_distance: float = 0.16
    right_sleep_distance: float = 0.20

    # Journal capture is not reward. It is recurrence + novelty only.
    journal_window: int = 24
    journal_min_unique: int = 5
    journal_recurrence: int = 2
