from __future__ import annotations
import math
from collections import Counter, deque
import numpy as np
from .substrate import SemanticSubstrate, clean_word, STOP
from .pockets import PocketStore
from .traffic import SemanticTraffic

class Hemisphere:
    def __init__(self, substrate: SemanticSubstrate, *, mode: str, hot_cap: int, dormant_cap: int, member_cap: int):
        if mode not in {"left", "right"}:
            raise ValueError(mode)
        self.s = substrate
        self.mode = mode
        self.pockets = PocketStore(substrate, hot_cap, dormant_cap, member_cap)
        self.state = self.s.idx.get("language", 0)
        self.w = float(self.s.wsig[self.state])
        self.visited = Counter()
        self.traffic = SemanticTraffic()
        self.turn = 0
        self.last_qv = None
        self.recent = deque(maxlen=64)

    def _params(self):
        if self.mode == "left":
            return dict(k=40, wkeep=.72, wx=.12, wy=-.09, wz=.17, dist=.62, ws=.18, visit=.13,
                        q=.0 if False else 2.05, qbonus=3.2, pocket=.035, hot_decay=.93, dorm_decay=.995,
                        sleep=.16, active=3, members=6)
        return dict(k=56, wkeep=.66, wx=.16, wy=-.08, wz=.22, dist=.45, ws=.12, visit=.075,
                    q=1.35, qbonus=2.35, pocket=.07, hot_decay=.96, dorm_decay=.997,
                    sleep=.20, active=5, members=12)

    def _manage_context(self, toks, qv, params):
        shifted = False
        if qv is not None and self.last_qv is not None:
            shifted = float(np.linalg.norm(qv - self.last_qv)) > 0.22
        if shifted:
            self.pockets.context_shift(qv, self.turn, params["sleep"])
            self.pockets.stats["context_switches"] += 1
        for t in toks:
            self.pockets.wake(t, self.s.idx[t], self.turn, 1.0)
        if qv is not None and len(self.pockets.hot) < self.pockets.hot_cap:
            nearby = self.pockets.nearby_dormant(qv)
            if nearby:
                _, key, seed = nearby
                self.pockets.wake(key, seed, self.turn, 0.5)
        self.last_qv = None if qv is None else qv.copy()
        return shifted

    def step(self, query: str | None = None, steps: int = 120, allow_spontaneous_pockets: bool = True):
        self.turn += 1
        p = self._params()
        toks = self.s.tokens(query or "")
        ids = [self.s.idx[t] for t in toks]
        qv = self.s.centre(ids)
        shifted = self._manage_context(toks, qv, p) if query else False
        self.pockets.decay(p["hot_decay"], p["dorm_decay"])

        path = []
        dists = []
        for sidx in range(steps):
            k = min(p["k"] + 1, len(self.s.words))
            dd, nn = self.s.tree.query(self.s.xyz[self.state], k=k)
            cand = list(map(int, np.atleast_1d(nn)[1:]))
            dl = list(map(float, np.atleast_1d(dd)[1:]))
            active = sorted(self.pockets.hot.values(), key=lambda x: x.activation, reverse=True)[:p["active"]]
            for pocket in active:
                for j, _ in pocket.members[:p["members"]]:
                    if j not in cand:
                        cand.append(j)
                        dl.append(float(np.linalg.norm(self.s.xyz[j] - self.s.xyz[self.state])))
            cand = np.asarray(cand, dtype=int)
            dl = np.asarray(dl, dtype=float)
            x, y, z = self.s.xyz[self.state]
            self.w = math.tanh(p["wkeep"] * self.w + p["wx"] * x + p["wy"] * y + p["wz"] * z)
            score = -p["dist"] * dl - p["ws"] * np.abs(self.s.wsig[cand] - self.w)
            score -= p["visit"] * np.log1p([self.visited[int(j)] for j in cand])
            if qv is not None:
                qd = np.linalg.norm(self.s.xyz[cand] - qv, axis=1)
                score -= p["q"] * qd
                for qi in ids:
                    score += (cand == qi) * p["qbonus"]
                dists.append(float(np.linalg.norm(self.s.xyz[self.state] - qv)))
            if self.mode == "right":
                score += .08 / (1 + np.asarray([self.visited[int(j)] for j in cand], dtype=float))
            for pocket in active:
                score -= p["pocket"] * pocket.activation * np.linalg.norm(self.s.xyz[cand] - pocket.centre, axis=1)

            order = np.argsort(score)[::-1]
            if self.mode == "left":
                pick = int(order[0])
            else:
                pick = int(order[min((sidx // 17) % 4, len(order) - 1)])
            self.state = int(cand[pick])
            self.visited[self.state] += 1
            word = self.s.words[self.state]
            path.append(word)
            self.recent.append(word)

            if self.mode == "right" and allow_spontaneous_pockets and self.visited[self.state] == 9:
                if clean_word(word) and word not in STOP and word not in self.pockets.hot:
                    self.pockets.wake(word, self.state, self.turn, .38)

        self.traffic.observe_path(path)
        cc = Counter(w for w in path if clean_word(w) and w not in toks and w not in STOP)
        concepts = [w for w, _ in cc.most_common(8 if self.mode == "left" else 10)]
        if dists:
            mean_d = float(np.mean(dists))
            hit = float(np.mean(np.asarray(dists) < .05))
            confidence = max(0., min(1., .55 * (1 / (1 + 10 * mean_d)) + .45 * hit)) if self.mode == "left" else max(0., min(1., .35 + .65 * min(1., len(set(path)) / max(1, len(path)) * 3)))
        else:
            mean_d, hit = None, None
            confidence = 0.0 if self.mode == "left" else max(0., min(1., .35 + .65 * min(1., len(set(path)) / max(1, len(path)) * 3)))
        return {
            "side": self.mode,
            "tokens": toks,
            "concepts": concepts,
            "path": path,
            "confidence": confidence,
            "mean_distance": mean_d,
            "hit_fraction": hit,
            "state": self.s.words[self.state],
            "hot": self.pockets.hot_words(),
            "dormant_count": len(self.pockets.dormant),
            "context_shift": shifted,
        }

    def snapshot(self):
        return {
            "mode": self.mode,
            "state": self.s.words[self.state],
            "w": self.w,
            "hot": self.pockets.hot_words(),
            "dormant": list(self.pockets.dormant),
            "pocket_stats": dict(self.pockets.stats),
            "traffic": self.traffic.to_dict(),
        }
