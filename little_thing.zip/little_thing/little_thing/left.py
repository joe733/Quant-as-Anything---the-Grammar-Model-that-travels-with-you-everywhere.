from .hemisphere import Hemisphere

class LeftBrain(Hemisphere):
    def __init__(self, substrate, hot_cap=6, dormant_cap=48):
        super().__init__(substrate, mode="left", hot_cap=hot_cap, dormant_cap=dormant_cap, member_cap=28)
