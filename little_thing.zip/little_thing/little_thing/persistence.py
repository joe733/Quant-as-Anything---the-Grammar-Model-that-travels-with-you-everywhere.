from __future__ import annotations
import json
from pathlib import Path


def save_brain(brain, path):
    path = Path(path)
    data = brain.export_state()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def load_brain(brain, path):
    path = Path(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    brain.import_state(data)
    return brain
