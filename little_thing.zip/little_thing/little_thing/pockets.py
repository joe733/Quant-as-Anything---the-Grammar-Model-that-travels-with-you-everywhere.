from __future__ import annotations
from dataclasses import dataclass, field
from collections import Counter
import numpy as np
from .substrate import SemanticSubstrate

@dataclass
class Pocket:
    key: str
    seed: int
    centre: np.ndarray
    members: list[tuple[int, float]]
    activation: float = 1.0
    uses: int = 1
    last_turn: int = 0

@dataclass
class DormantPocket:
    key: str
    seed: int
    activation: float
    uses: int
    last_turn: int

class PocketStore:
    """Hot/dormant working memory. No reward signal; only use, activation and capacity."""
    def __init__(self, substrate: SemanticSubstrate, hot_cap: int, dormant_cap: int, member_cap: int):
        self.s = substrate
        self.hot_cap = hot_cap
        self.dormant_cap = dormant_cap
        self.member_cap = member_cap
        self.hot: dict[str, Pocket] = {}
        self.dormant: dict[str, DormantPocket] = {}
        self.stats = Counter()

    def _members(self, seed: int):
        return self.s.neighbours(seed, self.member_cap)

    def sleep(self, key: str, turn: int, keep_if_used: int = 2, keep_activation: float = 0.55) -> None:
        p = self.hot.pop(key, None)
        if p is None:
            return
        if p.uses >= keep_if_used or p.activation >= keep_activation:
            self.dormant[key] = DormantPocket(key, p.seed, max(0.05, p.activation * 0.33), p.uses, turn)
            self.stats["slept"] += 1
            if len(self.dormant) > self.dormant_cap:
                # Mechanical cache eviction: least used, then oldest use.
                victim = min(self.dormant.values(), key=lambda x: (x.uses, x.last_turn))
                del self.dormant[victim.key]
                self.stats["forgotten"] += 1
        else:
            self.stats["discarded"] += 1

    def wake(self, key: str, seed: int, turn: int, activation: float = 0.8) -> None:
        if key in self.hot:
            p = self.hot[key]
            p.activation += 0.5
            p.uses += 1
            p.last_turn = turn
            return
        if len(self.hot) >= self.hot_cap:
            victim = min(self.hot.values(), key=lambda p: (p.activation, p.uses, p.last_turn))
            self.sleep(victim.key, turn)
        old = self.dormant.pop(key, None)
        self.hot[key] = Pocket(
            key=key,
            seed=seed,
            centre=self.s.xyz[seed].copy(),
            members=self._members(seed),
            activation=max(activation, old.activation if old else 0.0),
            uses=(old.uses + 1) if old else 1,
            last_turn=turn,
        )
        self.stats["reopened" if old else "opened"] += 1

    def decay(self, hot_factor: float, dormant_factor: float) -> None:
        for p in self.hot.values():
            p.activation *= hot_factor
        for p in self.dormant.values():
            p.activation *= dormant_factor

    def context_shift(self, qv: np.ndarray, turn: int, sleep_distance: float) -> None:
        for key, p in list(self.hot.items()):
            if float(np.linalg.norm(p.centre - qv)) > sleep_distance:
                self.sleep(key, turn)

    def nearby_dormant(self, qv: np.ndarray, radius: float = 0.075):
        candidates = []
        for key, p in self.dormant.items():
            d = float(np.linalg.norm(self.s.xyz[p.seed] - qv))
            if d < radius:
                candidates.append((d, key, p.seed))
        return min(candidates) if candidates else None

    def hot_words(self) -> list[str]:
        return list(self.hot)
