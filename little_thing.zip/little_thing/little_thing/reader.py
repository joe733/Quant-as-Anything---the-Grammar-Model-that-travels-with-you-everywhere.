from __future__ import annotations
import re

class Reader:
    """Turns long-form text into sequential semantic perturbations, not questions."""
    def __init__(self, brain):
        self.brain = brain

    def chunks(self, text: str, words_per_chunk: int = 90):
        words = re.findall(r"[A-Za-z']+", text)
        for i in range(0, len(words), words_per_chunk):
            yield " ".join(words[i:i + words_per_chunk])

    def read(self, text: str, words_per_chunk: int = 90, steps_per_chunk: int = 30):
        seen = 0
        for chunk in self.chunks(text, words_per_chunk):
            self.brain.absorb(chunk, steps=steps_per_chunk)
            seen += 1
        return {"chunks": seen, "words_per_chunk": words_per_chunk}
