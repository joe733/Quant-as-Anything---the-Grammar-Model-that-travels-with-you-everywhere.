from .hemisphere import Hemisphere

class RightBrain(Hemisphere):
    def __init__(self, substrate, hot_cap=8, dormant_cap=64):
        super().__init__(substrate, mode="right", hot_cap=hot_cap, dormant_cap=dormant_cap, member_cap=44)
