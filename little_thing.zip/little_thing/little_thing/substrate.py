from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np
from scipy.spatial import cKDTree

STOP = set("a an the of to and or in on by for from with without into upon is are was were be been being that this these those it its as at which who whom whose one two three four any all not no nor if than then when where what how their his her our your they he she we you i do does did done having have has had may might can could shall should will would something".split())


def clean_word(w: str) -> bool:
    return w.isalpha() and 3 <= len(w) <= 18 and not any(x in w for x in ("vv", "jj", "qqq"))


@dataclass
class SemanticSubstrate:
    words: list[str]
    coords: np.ndarray

    @classmethod
    def from_npz(cls, path: str | Path) -> "SemanticSubstrate":
        data = np.load(path, allow_pickle=False)
        return cls(data["words"].tolist(), np.asarray(data["coords"], dtype=float))

    def __post_init__(self) -> None:
        if self.coords.ndim != 2 or self.coords.shape[1] < 4:
            raise ValueError("coords must be N x >=4: x,y,z,w-signal")
        if len(self.words) != len(self.coords):
            raise ValueError("words and coords length mismatch")
        self.xyz = self.coords[:, :3]
        self.wsig = self.coords[:, 3]
        self.idx = {w: i for i, w in enumerate(self.words)}
        self.tree = cKDTree(self.xyz)

    def tokens(self, text: str) -> list[str]:
        return [t for t in re.findall(r"[a-z]+", text.lower()) if t in self.idx and t not in STOP]

    def centre(self, words_or_ids) -> np.ndarray | None:
        ids = []
        for x in words_or_ids:
            if isinstance(x, str):
                if x in self.idx:
                    ids.append(self.idx[x])
            else:
                ids.append(int(x))
        return self.xyz[ids].mean(axis=0) if ids else None

    def neighbours(self, seed: int | str, k: int = 48, clean: bool = True) -> list[tuple[int, float]]:
        if isinstance(seed, str):
            seed = self.idx[seed]
        query_k = min(len(self.words), max(k * 3, k + 1))
        d, n = self.tree.query(self.xyz[int(seed)], k=query_k)
        out = []
        for j, dist in zip(np.atleast_1d(n), np.atleast_1d(d)):
            j = int(j)
            w = self.words[j]
            if j == int(seed):
                continue
            if clean and (not clean_word(w) or w in STOP):
                continue
            out.append((j, float(dist)))
            if len(out) >= k:
                break
        return out

    def local_graph(self, seed: int | str, max_nodes: int = 48) -> tuple[list[int], np.ndarray]:
        if isinstance(seed, str):
            seed = self.idx[seed]
        neigh = self.neighbours(seed, max_nodes - 1)
        nodes = [int(seed)] + [j for j, _ in neigh]
        xyz = self.xyz[nodes]
        # Similarity only derives from geometry; no reward/penalty semantics.
        delta = xyz[:, None, :] - xyz[None, :, :]
        dist = np.linalg.norm(delta, axis=2)
        positive = dist[dist > 0]
        scale = float(np.median(positive)) if positive.size else 1.0
        adj = np.exp(-dist / max(scale, 1e-8)).astype(np.float32)
        np.fill_diagonal(adj, 0.0)
        return nodes, adj
