from __future__ import annotations
from collections import Counter

class SemanticTraffic:
    """Long-run semantic history. It stores traffic, not named values or traits."""
    def __init__(self):
        self.nodes = Counter()
        self.edges = Counter()

    def observe_path(self, path: list[str]) -> None:
        prev = None
        for w in path:
            self.nodes[w] += 1
            if prev is not None and prev != w:
                self.edges[(prev, w)] += 1
            prev = w

    def recurrent_nodes(self, n: int = 20):
        return self.nodes.most_common(n)

    def recurrent_edges(self, n: int = 20):
        return self.edges.most_common(n)

    def to_dict(self):
        return {
            "nodes": dict(self.nodes),
            "edges": {f"{a}\t{b}": c for (a, b), c in self.edges.items()},
        }

    @classmethod
    def from_dict(cls, d):
        x = cls()
        x.nodes.update(d.get("nodes", {}))
        for k, c in d.get("edges", {}).items():
            a, b = k.split("\t", 1)
            x.edges[(a, b)] = c
        return x
