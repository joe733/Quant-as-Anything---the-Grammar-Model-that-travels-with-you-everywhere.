from collections import Counter

class Voice:
    """Observed expression habits only. No reward signal and no fixed personality traits."""
    def __init__(self, category: str = "own"):
        self.category = category
        self.words = Counter()

    def observe_expression(self, words):
        self.words.update(words)

    def favourites(self, n=12):
        return [w for w, _ in self.words.most_common(n)]

    def to_dict(self):
        return {"category": self.category, "words": dict(self.words)}
