from little_thing import LittleThing, Reader, Daydreamer

def test_smoke():
    b = LittleThing()
    Reader(b).read("language meaning voice pause breath thought memory", words_per_chunk=8, steps_per_chunk=5)
    Daydreamer(b).run(40, chunk=20)
    out = b.ask("what is language?", steps_per_cycle=10, max_cycles=2)
    assert out["result"]["decision"] in {"speak", "unknown"}
    assert len(out["result"]["self"]) <= 12
    assert len(out["result"]["user"]) <= 12
    assert len(b.journal.entries) <= 128
